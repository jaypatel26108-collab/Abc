// Single source of truth for your markup.
// Your example was $20 supplier cost -> $25 storefront price, i.e. +25%.
// Change this one number to re-price your entire catalog instantly.
export const MARKUP_PERCENT = 25;

export function retailPrice(supplierCost: number): number {
  const price = supplierCost * (1 + MARKUP_PERCENT / 100);
  return Math.round(price * 100) / 100;
}

export function formatUSD(amount: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(amount);
}
