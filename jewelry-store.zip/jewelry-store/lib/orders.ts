import fs from "fs";
import path from "path";
import { nanoid } from "nanoid";

/**
 * ORDER STORAGE
 * -------------
 * This uses a local JSON file so the app works out of the box.
 * Vercel's filesystem is READ-ONLY and ephemeral in production, so
 * before you go live, swap this file's implementation for a real
 * database — Vercel Postgres, Supabase, or Vercel KV all work well
 * and take about 15 minutes to wire up. Everywhere else in the app
 * calls only the functions below, so that's the only file you'd touch.
 */

export type OrderStatus = "paid" | "placed_with_supplier" | "shipped" | "cancelled";

export type Order = {
  id: string;
  createdAt: string;
  customerEmail: string;
  shippingAddress: string;
  items: {
    slug: string;
    name: string;
    supplierUrl: string;
    supplierCost: number;
    retailPrice: number;
    quantity: number;
  }[];
  totalCharged: number;
  totalSupplierCost: number;
  status: OrderStatus;
};

const DB_PATH = path.join(process.cwd(), "orders.local.json");

function readAll(): Order[] {
  if (!fs.existsSync(DB_PATH)) return [];
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
  } catch {
    return [];
  }
}

function writeAll(orders: Order[]) {
  fs.writeFileSync(DB_PATH, JSON.stringify(orders, null, 2));
}

export function createOrder(input: Omit<Order, "id" | "createdAt" | "status">): Order {
  const order: Order = {
    ...input,
    id: nanoid(10),
    createdAt: new Date().toISOString(),
    status: "paid"
  };
  const orders = readAll();
  orders.unshift(order);
  writeAll(orders);
  return order;
}

export function listOrders(): Order[] {
  return readAll();
}

export function updateOrderStatus(id: string, status: OrderStatus): Order | null {
  const orders = readAll();
  const order = orders.find((o) => o.id === id);
  if (!order) return null;
  order.status = status;
  writeAll(orders);
  return order;
}
