export type Product = {
  slug: string;
  name: string;
  description: string;
  image: string;
  supplierUrl: string; // AliExpress product link — pre-filled for you at fulfillment time
  supplierCost: number; // what you pay the supplier, in USD
  category: "necklace" | "ring" | "earring" | "bracelet";
};

// Replace this list with your real AliExpress picks.
// supplierCost = what you pay AliExpress. Your storefront price is
// calculated automatically from MARKUP_PERCENT in lib/pricing.ts.
export const products: Product[] = [
  {
    slug: "moon-drop-necklace",
    name: "Moon Drop Necklace",
    description: "A slender gold-plated chain with a crescent pendant, cast in fine detail.",
    image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=800",
    supplierUrl: "https://www.aliexpress.com/item/REPLACE_ME.html",
    supplierCost: 8.4,
    category: "necklace"
  },
  {
    slug: "signet-ring",
    name: "Classic Signet Ring",
    description: "A weighted signet ring with a brushed matte finish, sized true to standard.",
    image: "https://images.unsplash.com/photo-1605100804763-247f67b3557e?w=800",
    supplierUrl: "https://www.aliexpress.com/item/REPLACE_ME.html",
    supplierCost: 6.2,
    category: "ring"
  },
  {
    slug: "cascade-hoop-earrings",
    name: "Cascade Hoop Earrings",
    description: "Triple-tier hoops that catch the light at every angle, hypoallergenic posts.",
    image: "https://images.unsplash.com/photo-1633555715049-73eae0fb0e14?w=800",
    supplierUrl: "https://www.aliexpress.com/item/REPLACE_ME.html",
    supplierCost: 5.1,
    category: "earring"
  },
  {
    slug: "linked-chain-bracelet",
    name: "Linked Chain Bracelet",
    description: "A substantial curb-link bracelet, adjustable clasp, tarnish-resistant plating.",
    image: "https://images.unsplash.com/photo-1611591437281-460bfbe1220a?w=800",
    supplierUrl: "https://www.aliexpress.com/item/REPLACE_ME.html",
    supplierCost: 7.3,
    category: "bracelet"
  }
];

export function getProduct(slug: string) {
  return products.find((p) => p.slug === slug);
}
