"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { products, type Product } from "./products";
import { retailPrice } from "./pricing";

type CartLine = { slug: string; quantity: number };
type CartContextType = {
  lines: CartLine[];
  add: (slug: string) => void;
  remove: (slug: string) => void;
  setQuantity: (slug: string, quantity: number) => void;
  clear: () => void;
  detailedLines: { product: Product; quantity: number; price: number }[];
  subtotal: number;
  count: number;
};

const CartContext = createContext<CartContextType | null>(null);
const STORAGE_KEY = "aurelie-cart";

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = window.sessionStorage.getItem(STORAGE_KEY);
      if (raw) setLines(JSON.parse(raw));
    } catch {}
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
  }, [lines, hydrated]);

  const add = (slug: string) => {
    setLines((prev) => {
      const existing = prev.find((l) => l.slug === slug);
      if (existing) {
        return prev.map((l) => (l.slug === slug ? { ...l, quantity: l.quantity + 1 } : l));
      }
      return [...prev, { slug, quantity: 1 }];
    });
  };

  const remove = (slug: string) => setLines((prev) => prev.filter((l) => l.slug !== slug));

  const setQuantity = (slug: string, quantity: number) =>
    setLines((prev) =>
      quantity <= 0 ? prev.filter((l) => l.slug !== slug) : prev.map((l) => (l.slug === slug ? { ...l, quantity } : l))
    );

  const clear = () => setLines([]);

  const detailedLines = useMemo(
    () =>
      lines
        .map((l) => {
          const product = products.find((p) => p.slug === l.slug);
          if (!product) return null;
          return { product, quantity: l.quantity, price: retailPrice(product.supplierCost) };
        })
        .filter(Boolean) as { product: Product; quantity: number; price: number }[],
    [lines]
  );

  const subtotal = detailedLines.reduce((sum, l) => sum + l.price * l.quantity, 0);
  const count = lines.reduce((sum, l) => sum + l.quantity, 0);

  return (
    <CartContext.Provider value={{ lines, add, remove, setQuantity, clear, detailedLines, subtotal, count }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
