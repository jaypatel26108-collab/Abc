/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,ts,jsx,tsx}", "./lib/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        onyx: "#14110F",
        onyx2: "#1C1815",
        ivory: "#EDE7DD",
        gold: "#C7A059",
        goldDim: "#8A6F3E",
        clay: "#A8763E",
        emerald: "#1F3D34"
      },
      fontFamily: {
        display: ["'Cormorant Garamond'", "serif"],
        body: ["'Work Sans'", "sans-serif"]
      },
      letterSpacing: {
        widest2: "0.25em"
      }
    }
  },
  plugins: []
};
