"use client";

import { useState } from "react";
import { useCart } from "@/lib/cart-context";

export default function AddToCartButton({ slug }: { slug: string }) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);

  return (
    <button
      onClick={() => {
        add(slug);
        setAdded(true);
        setTimeout(() => setAdded(false), 1500);
      }}
      className="border border-gold text-gold px-8 py-3 text-sm tracking-widest2 uppercase hover:bg-gold hover:text-onyx transition-colors"
    >
      {added ? "Added" : "Add to cart"}
    </button>
  );
}
