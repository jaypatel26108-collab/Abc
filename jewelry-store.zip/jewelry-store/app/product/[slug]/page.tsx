import Image from "next/image";
import { notFound } from "next/navigation";
import { getProduct } from "@/lib/products";
import { retailPrice, formatUSD } from "@/lib/pricing";
import AddToCartButton from "./AddToCartButton";

export default function ProductPage({ params }: { params: { slug: string } }) {
  const product = getProduct(params.slug);
  if (!product) return notFound();

  return (
    <div className="max-w-6xl mx-auto px-6 py-16 grid md:grid-cols-2 gap-12">
      <div className="relative aspect-square bg-onyx2">
        <Image src={product.image} alt={product.name} fill className="object-cover" priority />
      </div>
      <div>
        <h1 className="font-display text-4xl text-ivory">{product.name}</h1>
        <p className="text-gold text-2xl mt-3">{formatUSD(retailPrice(product.supplierCost))}</p>
        <p className="mt-6 text-ivory/70 leading-relaxed max-w-md">{product.description}</p>
        <div className="mt-8">
          <AddToCartButton slug={product.slug} />
        </div>
        <p className="mt-6 text-xs text-ivory/40">Ships in 12–20 days · Tracking sent by email</p>
      </div>
    </div>
  );
}
