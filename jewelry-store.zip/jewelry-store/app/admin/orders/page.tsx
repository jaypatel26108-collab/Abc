"use client";

import { useEffect, useState } from "react";

type Order = {
  id: string;
  createdAt: string;
  customerEmail: string;
  shippingAddress: string;
  items: { name: string; supplierUrl: string; supplierCost: number; retailPrice: number; quantity: number }[];
  totalCharged: number;
  totalSupplierCost: number;
  status: string;
};

export default function AdminOrdersPage() {
  const [key, setKey] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [error, setError] = useState("");

  const load = async (adminKey: string) => {
    const res = await fetch("/api/orders", { headers: { "x-admin-key": adminKey } });
    if (!res.ok) {
      setError("Wrong admin key.");
      return;
    }
    const data = await res.json();
    setOrders(data.orders);
    setUnlocked(true);
    setError("");
  };

  const markPlaced = async (id: string) => {
    await fetch("/api/orders", {
      method: "PATCH",
      headers: { "Content-Type": "application/json", "x-admin-key": key },
      body: JSON.stringify({ id, status: "placed_with_supplier" })
    });
    load(key);
  };

  if (!unlocked) {
    return (
      <div className="max-w-sm mx-auto px-6 py-24">
        <h1 className="font-display text-2xl text-ivory mb-6">Admin</h1>
        <input
          type="password"
          placeholder="Admin key"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          className="w-full bg-onyx2 border border-goldDim/30 px-3 py-2 text-ivory"
        />
        <button
          onClick={() => load(key)}
          className="mt-4 w-full border border-gold text-gold py-2 text-sm uppercase tracking-widest2"
        >
          Enter
        </button>
        {error && <p className="text-clay text-sm mt-3">{error}</p>}
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-16">
      <h1 className="font-display text-3xl text-ivory mb-10">Fulfillment queue</h1>
      {orders.length === 0 && <p className="text-ivory/50">No orders yet.</p>}
      <div className="space-y-6">
        {orders.map((o) => (
          <div key={o.id} className="border border-goldDim/20 p-5">
            <div className="flex justify-between text-sm text-ivory/50">
              <span>{new Date(o.createdAt).toLocaleString()}</span>
              <span className="uppercase tracking-wide text-gold">{o.status}</span>
            </div>
            <p className="mt-2 text-ivory">{o.customerEmail}</p>
            <p className="text-ivory/50 text-sm">{o.shippingAddress}</p>
            <div className="mt-4 space-y-2">
              {o.items.map((it, i) => (
                <div key={i} className="flex justify-between text-sm">
                  <a href={it.supplierUrl} target="_blank" className="text-gold underline">
                    {it.quantity}× {it.name} — place on AliExpress
                  </a>
                  <span className="text-ivory/50">
                    cost ${it.supplierCost} · charged ${it.retailPrice}
                  </span>
                </div>
              ))}
            </div>
            <div className="mt-4 flex justify-between items-center">
              <span className="text-sm text-ivory/60">
                Profit: ${(o.totalCharged - o.totalSupplierCost).toFixed(2)}
              </span>
              {o.status === "paid" && (
                <button
                  onClick={() => markPlaced(o.id)}
                  className="text-xs border border-gold text-gold px-4 py-2 uppercase tracking-widest2"
                >
                  Mark placed with supplier
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
