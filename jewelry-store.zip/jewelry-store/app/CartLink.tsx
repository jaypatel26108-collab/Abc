"use client";

import Link from "next/link";
import { useCart } from "@/lib/cart-context";

export default function CartLink() {
  const { count } = useCart();
  return (
    <Link href="/cart" className="hover:text-gold transition-colors">
      Cart{count > 0 ? ` (${count})` : ""}
    </Link>
  );
}
