"use client";

import { useEffect } from "react";
import Link from "next/link";
import { useCart } from "@/lib/cart-context";

export default function SuccessPage() {
  const { clear } = useCart();

  useEffect(() => {
    clear();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="max-w-xl mx-auto px-6 py-24 text-center">
      <h1 className="font-display text-3xl text-ivory">Thank you.</h1>
      <p className="mt-4 text-ivory/70">
        Your order is confirmed. You'll receive tracking details by email once it ships.
      </p>
      <Link href="/#shop" className="inline-block mt-8 text-gold underline underline-offset-4">
        Continue shopping
      </Link>
    </div>
  );
}
