import Link from "next/link";
import Image from "next/image";
import { products } from "@/lib/products";
import { retailPrice, formatUSD } from "@/lib/pricing";

export default function HomePage() {
  return (
    <div>
      <section className="max-w-6xl mx-auto px-6 pt-16 pb-20 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <p className="text-gold text-xs tracking-widest2 uppercase mb-4">New season, small batch</p>
          <h1 className="font-display text-5xl md:text-6xl leading-[1.05] text-ivory">
            Pieces worth <span className="italic text-gold">keeping.</span>
          </h1>
          <p className="mt-6 text-ivory/70 max-w-md leading-relaxed">
            Considered jewelry in gold-plated brass and stainless steel — chosen a few pieces at a
            time, not mass-produced. Each order ships within one business day of confirmation.
          </p>
          <Link
            href="#shop"
            className="inline-block mt-8 border border-gold text-gold px-7 py-3 text-sm tracking-widest2 uppercase hover:bg-gold hover:text-onyx transition-colors"
          >
            Shop the edit
          </Link>
        </div>
        <div className="relative aspect-square rounded-full overflow-hidden border border-goldDim/30">
          <Image
            src="https://images.unsplash.com/photo-1602751584547-8ac1a1e05a5a?w=1000"
            alt="Model wearing layered gold jewelry"
            fill
            className="object-cover"
            priority
          />
        </div>
      </section>

      <div className="chain-divider max-w-6xl mx-auto" />

      <section id="shop" className="max-w-6xl mx-auto px-6 py-16">
        <h2 className="font-display text-3xl text-ivory mb-10">The edit</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((p) => (
            <Link key={p.slug} href={`/product/${p.slug}`} className="group">
              <div className="relative aspect-[4/5] overflow-hidden bg-onyx2">
                <Image
                  src={p.image}
                  alt={p.name}
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="mt-4">
                <h3 className="font-display text-lg text-ivory">{p.name}</h3>
                <p className="text-gold text-sm mt-1">{formatUSD(retailPrice(p.supplierCost))}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
