"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useCart } from "@/lib/cart-context";
import { formatUSD } from "@/lib/pricing";

export default function CartPage() {
  const { detailedLines, subtotal, setQuantity, remove, clear } = useCart();
  const [loading, setLoading] = useState(false);

  const checkout = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lines: detailedLines.map((l) => ({ slug: l.product.slug, quantity: l.quantity })) })
      });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
    } finally {
      setLoading(false);
    }
  };

  if (detailedLines.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-6 py-24 text-center">
        <p className="font-display text-2xl text-ivory">Your cart is empty.</p>
        <Link href="/#shop" className="inline-block mt-6 text-gold underline underline-offset-4">
          Back to the edit
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-16">
      <h1 className="font-display text-3xl text-ivory mb-10">Your cart</h1>
      <div className="space-y-6">
        {detailedLines.map(({ product, quantity, price }) => (
          <div key={product.slug} className="flex gap-4 items-center border-b border-goldDim/20 pb-6">
            <div className="relative w-20 h-24 bg-onyx2 shrink-0">
              <Image src={product.image} alt={product.name} fill className="object-cover" />
            </div>
            <div className="flex-1">
              <h3 className="font-display text-lg text-ivory">{product.name}</h3>
              <p className="text-gold text-sm mt-1">{formatUSD(price)}</p>
              <div className="flex items-center gap-3 mt-2">
                <label className="text-xs text-ivory/50" htmlFor={`qty-${product.slug}`}>Qty</label>
                <input
                  id={`qty-${product.slug}`}
                  type="number"
                  min={1}
                  value={quantity}
                  onChange={(e) => setQuantity(product.slug, Number(e.target.value))}
                  className="w-16 bg-onyx2 border border-goldDim/30 px-2 py-1 text-ivory text-sm"
                />
                <button onClick={() => remove(product.slug)} className="text-xs text-ivory/40 hover:text-clay underline">
                  Remove
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10 flex justify-between items-baseline">
        <span className="text-ivory/60">Subtotal</span>
        <span className="font-display text-2xl text-ivory">{formatUSD(subtotal)}</span>
      </div>

      <button
        onClick={checkout}
        disabled={loading}
        className="mt-8 w-full border border-gold text-gold py-4 text-sm tracking-widest2 uppercase hover:bg-gold hover:text-onyx transition-colors disabled:opacity-50"
      >
        {loading ? "Redirecting…" : "Checkout"}
      </button>
      <button onClick={clear} className="mt-4 text-xs text-ivory/40 underline">
        Clear cart
      </button>
    </div>
  );
}
