import "./globals.css";
import type { Metadata } from "next";
import Link from "next/link";
import { CartProvider } from "@/lib/cart-context";
import CartLink from "./CartLink";

export const metadata: Metadata = {
  title: "Aurélie — Fine costume jewelry",
  description: "Small, considered pieces. Shipped to your door."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-body antialiased">
        <CartProvider>
          <header className="sticky top-0 z-40 backdrop-blur bg-onyx/90 border-b border-goldDim/20">
            <div className="max-w-6xl mx-auto flex items-center justify-between px-6 py-5">
              <Link href="/" className="font-display text-2xl tracking-widest2 text-ivory">
                AURÉLIE
              </Link>
              <nav className="flex items-center gap-8 text-sm tracking-wide text-ivory/80">
                <Link href="/#shop" className="hover:text-gold transition-colors">Shop</Link>
                <CartLink />
              </nav>
            </div>
          </header>
          <main>{children}</main>
          <footer className="mt-24 border-t border-goldDim/20">
            <div className="max-w-6xl mx-auto px-6 py-10 text-xs text-ivory/50 flex justify-between">
              <span>© {new Date().getFullYear()} Aurélie</span>
              <span>Shipping 12–20 days · All sales final</span>
            </div>
          </footer>
        </CartProvider>
      </body>
    </html>
  );
}
