import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { getProduct } from "@/lib/products";
import { retailPrice } from "@/lib/pricing";
import { createOrder } from "@/lib/orders";

// This endpoint is called by Stripe, not by your site's users.
// Register it in the Stripe dashboard as: https://yourdomain.com/api/webhook
// listening for the "checkout.session.completed" event.

export async function POST(req: NextRequest) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
  const sig = req.headers.get("stripe-signature")!;
  const body = await req.text();

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch (err) {
    return NextResponse.json({ error: `Webhook signature verification failed` }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const fullSession = await stripe.checkout.sessions.retrieve(session.id, {
      expand: ["line_items", "line_items.data.price.product"]
    });

    const items = (fullSession.line_items?.data || []).map((li) => {
      const productData = li.price?.product as Stripe.Product;
      const slug = productData?.metadata?.slug;
      const product = slug ? getProduct(slug) : undefined;
      return {
        slug: slug || "unknown",
        name: productData?.name || "Unknown item",
        supplierUrl: product?.supplierUrl || "",
        supplierCost: product?.supplierCost || 0,
        retailPrice: product ? retailPrice(product.supplierCost) : 0,
        quantity: li.quantity || 1
      };
    });

    const totalSupplierCost = items.reduce((sum, i) => sum + i.supplierCost * i.quantity, 0);
    const shipping = fullSession.customer_details;

    createOrder({
      customerEmail: shipping?.email || "unknown",
      shippingAddress: JSON.stringify(fullSession.customer_details?.address || {}),
      items,
      totalCharged: (fullSession.amount_total || 0) / 100,
      totalSupplierCost
    });

    // Optional: send yourself an email/Slack notification here so you
    // know to go place the supplier order. See README for suggestions.
  }

  return NextResponse.json({ received: true });
}
