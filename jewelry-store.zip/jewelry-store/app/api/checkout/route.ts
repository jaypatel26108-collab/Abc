import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { getProduct } from "@/lib/products";
import { retailPrice } from "@/lib/pricing";

export async function POST(req: NextRequest) {
  if (!process.env.STRIPE_SECRET_KEY) {
    return NextResponse.json(
      { error: "STRIPE_SECRET_KEY is not set. Add it to your environment variables." },
      { status: 500 }
    );
  }

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const { lines } = (await req.json()) as { lines: { slug: string; quantity: number }[] };

  const line_items = lines
    .map((l) => {
      const product = getProduct(l.slug);
      if (!product) return null;
      return {
        quantity: l.quantity,
        price_data: {
          currency: "usd",
          unit_amount: Math.round(retailPrice(product.supplierCost) * 100),
          product_data: { name: product.name, metadata: { slug: product.slug } }
        }
      };
    })
    .filter(Boolean) as Stripe.Checkout.SessionCreateParams.LineItem[];

  if (line_items.length === 0) {
    return NextResponse.json({ error: "No valid items in cart." }, { status: 400 });
  }

  const origin = req.headers.get("origin") || "http://localhost:3000";

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    line_items,
    shipping_address_collection: { allowed_countries: ["US", "CA", "GB", "AU"] },
    success_url: `${origin}/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${origin}/cart`
  });

  return NextResponse.json({ url: session.url });
}
