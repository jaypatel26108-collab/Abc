# Aurélie — jewelry dropshipping storefront

A Next.js storefront with Stripe checkout and a fulfillment queue for AliExpress dropshipping.

## How it works

1. Customer browses products and checks out via Stripe.
2. On successful payment, a Stripe webhook creates an order in your **fulfillment queue**
   (`/admin/orders`) with the AliExpress product link, cost, and shipping address ready to go.
3. You click the link, place the order on AliExpress using the customer's shipping address,
   and mark it "placed with supplier."

**Why not fully automatic ordering on AliExpress?** AliExpress doesn't offer a public API for
individual sellers to auto-place orders — and building a bot to do it through their checkout
page would violate their Terms of Service and risk your account. The queue above takes about
30 seconds per order and is the standard, account-safe way independent dropshippers run this.
If you want true one-click automation later, **CJDropshipping** has a legitimate order API —
ask me and I'll wire up an integration in `lib/orders.ts`.

## 1. Local setup

```bash
npm install
cp .env.example .env.local
# fill in STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET, ADMIN_KEY
npm run dev
```

Visit `http://localhost:3000`.

## 2. Add your real products

Edit `lib/products.ts`. For each item:
- `supplierUrl`: the AliExpress product page link
- `supplierCost`: what AliExpress charges you
- Your storefront price is calculated automatically — see `lib/pricing.ts`,
  where `MARKUP_PERCENT = 25` matches your $20 → $25 example. Change that one
  number to re-price everything.

Swap the Unsplash placeholder images for the supplier's actual product photos
(download them and put them in `/public`, or use the AliExpress image URL directly).

## 3. Stripe setup

1. Create a Stripe account: https://dashboard.stripe.com
2. Get your API key from **Developers → API keys**
3. Once deployed, go to **Developers → Webhooks → Add endpoint**, use
   `https://yourdomain.vercel.app/api/webhook`, and select the
   `checkout.session.completed` event. Copy the signing secret into
   `STRIPE_WEBHOOK_SECRET`.

## 4. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

## 5. Deploy on Vercel

1. Go to https://vercel.com/new and import your GitHub repo
2. Add environment variables (`STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `ADMIN_KEY`)
   under **Project Settings → Environment Variables**
3. Deploy
4. Go back to Stripe and point your webhook at the live Vercel URL

## 6. Before taking real orders

- Swap `lib/orders.ts`'s file-based storage for a real database (Vercel Postgres or
  Supabase — Vercel's filesystem doesn't persist writes in production). This is the
  one thing in this scaffold that's demo-only; everything else is production-ready.
- Set up a business entity/payment account matching your region's requirements —
  I'm not a lawyer, so check local rules on sales tax and consumer protection for
  dropshipping specifically (return windows, disclosure of shipping times, etc.)
- Consider adding order-confirmation emails (Resend or Postmark are simple to add)

## Admin dashboard

Visit `/admin/orders` and enter your `ADMIN_KEY` to see incoming orders and the
AliExpress link for each item.
